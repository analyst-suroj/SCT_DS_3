# Final Bank Marketing Analysis
print("=== TASK 03: BANK MARKETING DECISION TREE ===")

# Import packages
from ucimlrepo import fetch_ucirepo
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder

print("✓ All packages imported")

# Load dataset
print("\n1. Loading dataset...")
bank_marketing = fetch_ucirepo(id=222)
X = bank_marketing.data.features
y = bank_marketing.data.targets

print(f"✓ Dataset: {X.shape[0]} rows, {X.shape[1]} features")

# Prepare data
print("\n2. Preparing data...")
if isinstance(y, pd.DataFrame):
    y = y.iloc[:, 0]

# Convert text to numbers
for column in X.columns:
    if X[column].dtype == 'object':
        X[column] = LabelEncoder().fit_transform(X[column].astype(str))

y_encoded = LabelEncoder().fit_transform(y.astype(str))
print("✓ Data converted to numeric format")

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)
print(f"✓ Split: {len(X_train)} training, {len(X_test)} testing samples")

# Train model
print("\n3. Training decision tree...")
model = DecisionTreeClassifier(random_state=42, max_depth=5)
model.fit(X_train, y_train)
print("✓ Model trained")

# Evaluate
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print("\n" + "="*50)
print("🎯 FINAL RESULTS:")
print(f"Model Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
print("="*50)
print("✅ TASK 03 COMPLETED SUCCESSFULLY!")