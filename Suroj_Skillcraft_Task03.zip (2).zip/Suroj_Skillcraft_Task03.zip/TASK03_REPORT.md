# TASK 03: Decision Tree Classifier for Bank Marketing
## Internship Project

### Project Information
- *Intern Name*: Suraj
- *Company*: SkillCraft Technology
- *Date*: 2/11/25
- *Project*: Build decision tree to predict customer purchases for banking products

### Business Objective
Develop a machine learning model to predict whether customers will purchase banking products based on demographic and behavioral data to improve marketing campaign efficiency.

### Results & Achievements
- *Model Accuracy*: 89.59%
- *Dataset*: Bank Marketing from UCI Repository
- *Algorithm*: Decision Tree Classifier
- *Training Samples*: 36,168
- *Testing Samples*: 9,043
- *Business Impact*: Model can accurately predict customer behavior, potentially reducing marketing costs and increasing conversion rates

### Technical Implementation
- *Code Files*: 
  - final_bank.py - Production-ready implementation
  - simple_bank.py - Prototype implementation
- *Technologies*: Python, pandas, scikit-learn
- *Data Source*: UCI Machine Learning Repository

### Requirements
- Python 3.x
- pandas, scikit-learn, ucimlrepo

### Deployment
```bash
python final_bank.py